import { apks, auditEvents, devices, plans, tasks, works } from '@/data/mock'
import type { ApkArtifact, Device, PublishPlan, TaskRun, Work } from '@/types'

type MockCollection = {
  devices: Device[]
  works: Work[]
  plans: PublishPlan[]
  tasks: TaskRun[]
  apks: ApkArtifact[]
  audit: typeof auditEvents
}

const collections: MockCollection = { devices, works, plans, tasks, apks, audit: auditEvents }

const sleep = (milliseconds: number) => new Promise((resolve) => window.setTimeout(resolve, milliseconds))

export const apiClient = {
  async list<K extends keyof MockCollection>(resource: K): Promise<MockCollection[K]> {
    await sleep(90)
    return structuredClone(collections[resource])
  },
  async getDevice(id: string) {
    await sleep(70)
    const device = devices.find((item) => item.id === id)
    if (!device) throw new Error('设备不存在或当前租户无权访问')
    return structuredClone(device)
  },
  async getPlan(id: string) {
    await sleep(70)
    const plan = plans.find((item) => item.id === id)
    if (!plan) throw new Error('发布计划不存在')
    return structuredClone(plan)
  },
  async getTask(id: string) {
    await sleep(70)
    const task = tasks.find((item) => item.id === id)
    if (!task) throw new Error('任务运行不存在')
    return structuredClone(task)
  },
  async submitAction(action: string) {
    await sleep(180)
    return { action, accepted: true, requestId: `req-mock-${Date.now()}`, simulation: true }
  },
}
