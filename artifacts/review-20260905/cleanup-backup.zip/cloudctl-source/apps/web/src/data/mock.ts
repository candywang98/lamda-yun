import type { ApkArtifact, Device, PublishPlan, TaskRun, Work } from '@/types'

export const devices: Device[] = [
  { id: 'dev-hz-023', name: '杭州-内容-023', status: 'ONLINE', android: '14', lamda: '10.6', app: '8.32.1', edge: 'edge-hz-a', battery: 87, temperature: 33.4, account: '内容号-华东-12', capability: 'Root / arm64', lease: 'lease-7f21 · token 184' },
  { id: 'dev-sh-014', name: '上海-内容-014', status: 'RUNNING', android: '16', lamda: '10.8', app: '8.32.1', edge: 'edge-sh-b', battery: 64, temperature: 38.1, account: '品牌号-07', capability: 'Shizuku / arm64', lease: 'lease-880a · token 41' },
  { id: 'dev-bj-008', name: '北京-实验-008', status: 'MAINTENANCE', android: '17', lamda: '10.8', app: '8.31.7', edge: 'edge-bj-lab', battery: 100, temperature: 29.8, account: '授权测试号-02', capability: 'non-root / arm64', lease: '调试会话占用' },
  { id: 'dev-gz-031', name: '广州-内容-031', status: 'OFFLINE', android: '12', lamda: '10.6', app: '8.31.7', edge: 'edge-gz-a', battery: 21, temperature: 31.2, account: '内容号-华南-03', capability: 'Root / arm64' },
]

export const works: Work[] = [
  { id: 'work-1088', title: '秋季新品开箱短片', revision: 6, group: '新品内容', status: 'APPROVED', author: '陈编辑', updatedAt: '2026-08-30 09:42', media: 4 },
  { id: 'work-1083', title: '门店周末活动预告', revision: 3, group: '本地活动', status: 'PENDING_APPROVAL', author: '唐内容', updatedAt: '2026-08-30 08:17', media: 2 },
  { id: 'work-1071', title: '产品使用技巧 03', revision: 8, group: '教程系列', status: 'SUCCEEDED', author: '陈编辑', updatedAt: '2026-08-29 17:05', media: 3 },
  { id: 'work-1064', title: '八月品牌故事', revision: 2, group: '品牌栏目', status: 'CANCELED', author: '许策划', updatedAt: '2026-08-28 15:21', media: 1 },
]

export const plans: PublishPlan[] = [
  { id: 'plan-240830-018', title: '秋季新品开箱 / 华东首批', status: 'PENDING_APPROVAL', creator: '李发布', approver: '待指派', targets: 12, succeeded: 0, failed: 0, unknown: 0, schedule: '2026-08-30 18:30', snapshot: 'snap-85d2b2 · rev 6', automation: 'rednote-publish@2.4.1' },
  { id: 'plan-240829-011', title: '产品使用技巧 03 / 全量', status: 'PARTIAL', creator: '李发布', approver: '林审核', targets: 28, succeeded: 25, failed: 2, unknown: 1, schedule: '2026-08-29 20:00', snapshot: 'snap-b4c8f0 · rev 8', automation: 'rednote-publish@2.4.0' },
  { id: 'plan-240828-007', title: '门店周末活动 / 华南', status: 'CANCELED', creator: '郑发布', approver: '孙安全', targets: 8, succeeded: 2, failed: 0, unknown: 0, schedule: '2026-08-28 16:00', snapshot: 'snap-2d1fc9 · rev 2', automation: 'rednote-publish@2.4.0' },
]

export const tasks: TaskRun[] = [
  { id: 'run-9e41', plan: 'plan-240829-011', status: 'UNKNOWN', adapter: 'rednote', targetCount: 1, succeeded: 0, failed: 0, unknown: 1, startedAt: '2026-08-29 20:16', duration: '12m 44s', creator: '李发布', version: '2.4.0', step: 'RECONCILE / 等待人工对账', cancellable: false },
  { id: 'run-4ab2', plan: 'plan-240830-018', status: 'QUEUED', adapter: 'rednote', targetCount: 12, succeeded: 0, failed: 0, unknown: 0, startedAt: '计划 18:30', duration: '-', creator: '李发布', version: '2.4.1', step: '等待审批', cancellable: true },
  { id: 'run-2fc8', plan: 'plan-240829-011', status: 'SUCCEEDED', adapter: 'rednote', targetCount: 25, succeeded: 25, failed: 0, unknown: 0, startedAt: '2026-08-29 20:00', duration: '28m 09s', creator: '李发布', version: '2.4.0', step: '完成', cancellable: false },
  { id: 'run-f088', plan: 'plan-240829-011', status: 'FAILED', adapter: 'rednote', targetCount: 2, succeeded: 0, failed: 2, unknown: 0, startedAt: '2026-08-29 20:02', duration: '3m 41s', creator: '李发布', version: '2.4.0', step: 'PREPARE / APP_STATE', cancellable: false },
  { id: 'run-d287', plan: 'plan-240828-007', status: 'CANCELED', adapter: 'rednote', targetCount: 6, succeeded: 0, failed: 0, unknown: 0, startedAt: '2026-08-28 16:04', duration: '1m 10s', creator: '郑发布', version: '2.4.0', step: '在安全点取消', cancellable: false },
]

export const apks: ApkArtifact[] = [
  { id: 'apk-311', packageName: 'com.example.companion', version: '1.8.2 (182)', signer: 'CloudCtl Companion Release', abi: 'arm64-v8a', sdk: '26–35', hash: '9c2e…81af', scan: 'SUCCEEDED', permissions: '+0 / -0', channel: 'stable' },
  { id: 'apk-309', packageName: 'com.example.companion', version: '1.9.0-rc2 (19002)', signer: 'CloudCtl Companion Release', abi: 'arm64-v8a', sdk: '26–35', hash: '2f71…d0c4', scan: 'CANDIDATE', permissions: '+1 通知（待审批）', channel: 'candidate' },
  { id: 'apk-302', packageName: 'com.example.firerpa.server', version: '10.8.0 (10800)', signer: '官方签名 · 7A:31:…', abi: 'arm64 + splits', sdk: '24–35', hash: 'ef08…c931', scan: 'SUCCEEDED', permissions: '与 10.6 一致', channel: 'candidate' },
]

export const auditEvents = [
  { time: '10:42:17', actor: '林审核', action: 'PUBLISH_PLAN.REVIEW_OPENED', target: 'plan-240830-018', result: '允许', request: 'req-0f8d' },
  { time: '10:31:02', actor: '王运维', action: 'DEVICE.MAINTENANCE_ENTERED', target: 'dev-bj-008', result: '成功', request: 'req-1a23' },
  { time: '10:14:44', actor: 'system-service', action: 'EDGE.CERT_ROTATED', target: 'edge-sh-b', result: '成功', request: 'req-830f' },
  { time: '09:57:06', actor: '唐内容', action: 'WORK.REVISION_SUBMITTED', target: 'work-1083/r3', result: '待审批', request: 'req-12a2' },
]
