# LAMDA 云控系统 V1 重新审视与开发计划

**基线日期：2026-09-05**  
**目标：**先打通“商品库/素材库 -> 账号绑定 -> 手机端执行 -> 平台发布结果回传”的最小闭环，再扩展平台与批量能力。

## 1. 当前结论

### 1.1 项目形态

当前仓库是一个以 `cloudctl-source` 为源码根目录的 Monorepo，包含：

- Web 控制台：`apps/web`，Vue 3 + Vite。
- Studio 调试端：`apps/studio`，Vue 3 + Monaco。
- 控制 API：`services/control-api`，FastAPI + SQLAlchemy + Alembic。
- Edge/Hub/Worker/Outbox：Python 服务链，负责设备连接、任务调度、执行记录与事件分发。
- Android Companion：`mobile/companion`，通过 AccessibilityService 执行受限 UI 任务。
- 可选 DPC：`mobile/dpc`，设备策略能力，不属于首个业务闭环的必需条件。
- 共享协议与领域包：`packages/*`。

### 1.2 已有能力（代码已存在，但不等于生产可用）

- 账号、设备、绑定、租约、素材上传/资产登记、内容/商品内容分组、发布计划、提交意图等 API 已有骨架。
- Web 已有商品/帖子编辑入口，并能创建内容和移动任务。
- 手机端已具备注册、心跳、任务领取、租约、事件、完成/失败回传机制。
- 闲鱼当前只有“填写描述和价格并截图留证”的受限文本发布配方；代码注释明确指出图片上传和最终点击发布尚未实现。
- APK `0.1.0` 已安装到 OnePlus 9R，设备序列号为 `b0644fb5`，但 APK 仍是 `debuggable=true` 的调试构建。

### 1.3 未完成的关键闭环

1. 素材文件没有形成“云端资产 -> 手机本地可验证文件 -> 平台图片/视频选择器”的完整传输协议。
2. 商品库和素材库的领域模型还没有按 V1 业务语义拆清楚；现有 `ContentItem` 更像通用内容/商品容器。
3. 账号授权目前是控制面记录与设备绑定，不等于对小红书、抖音、微信公众号、闲鱼的真实登录态/授权态已可用。
4. 只有有限的操作适配器，不能声称 134 个竞品页面都已实现。
5. 没有可证明的多平台统一发布状态机、失败重试规则、人工确认点和结果对账。
6. Python 环境不可重复：项目声明 Python >=3.12，但当前直接执行曾落到系统 Python 3.10/3.13；虚拟环境还缺 `google.protobuf`、`temporalio` 等依赖。

## 2. 当前进度评估

进度采用“可运行证据”而不是文件数量计算。

| 能力域 | 当前判断 | 估计完成度 | 依据/缺口 |
| --- | --- | ---: | --- |
| 工程骨架与安全边界 | 已有骨架 | 70% | 有 ADR、租约/围栏、权限和边界测试；尚未形成稳定可复现 CI |
| Web 控制台 | 可演示 | 45% | Web 单测 39 个通过；大量页面仍是目录/工作台和 mock 数据 |
| Studio | 可演示 | 40% | 单测 16 个通过；真实调试 runner 和持久化草稿仍不完整 |
| Control API | 骨架较完整 | 60% | 账号、素材、内容、发布计划、移动任务路由存在；缺真实平台适配与完整业务闭环 |
| Android Companion | 任务执行骨架 | 45% | 已安装运行；缺素材交付、平台页面适配矩阵、真实发布验收 |
| 闲鱼 V1 | 文本预填阶段 | 25% | 当前配方未上传图片、未点击最终发布 |
| 素材库 | 资产管理骨架 | 30% | 已有上传/登记/衍生物接口；缺本地投递、缩略图/元数据、引用关系和平台校验 |
| 商品库 | 通用内容模型阶段 | 25% | 可保存部分商品字段；缺 SKU、库存、运费、分类、商品媒体集合和版本审批 |
| 多平台发布 | 尚未形成 V1 | 10% | 有发布计划概念；缺平台适配器、统一回执和失败对账 |
| 生产验收 | 未开始 | 0% | 旧状态文档也明确硬件/生产验收为 pending 或 blocked_hardware |

**总体判断：约 40%：**架构与验证投入较多，业务闭环尚未完成。这个数字是项目管理估算，不是测试测量值。

## 3. V1 范围冻结

### 必做

- 商品库：商品主数据、价格、描述、分类、图片集合、发布模板、版本。
- 素材库：图片/视频/图文素材、标签、分组、缩略图、哈希去重、引用关系。
- 账号中心：平台账号、设备绑定、授权状态、最后检查时间、失效原因。
- 首个平台：**闲鱼**。先实现“一台已授权手机、一个账号、一个商品、人工确认后发布”。
- 内容平台：先实现“素材发送到手机并能在目标 App 的选择器中被选中”；小红书/抖音/微信公众号先做适配器接口和能力矩阵，不在第一阶段承诺全自动发布。
- 发布中心：单次发布、预览、人工确认、执行日志、结果截图/回执、失败重试前的人工复核。

### 明确不做

- 不做任意 shell、Frida、MITM、验证码绕过、反检测、养号、虚假流量或未经授权批量操作。
- 不做“所有平台一次接通”的假完成；每个平台必须单独有授权、页面定位、素材格式和硬件验收证据。
- 不做自动重复提交。提交采用 `commit_intent -> commit_once -> reconcile`，不确定结果时只对账，不自动再次点击发布。
- 不把当前竞品目录的 134 项当作 V1 交付范围。

## 4. 推荐系统方案

### 4.1 领域模型

新增或明确以下实体，保持 PostgreSQL 为业务事实源：

```text
Product
  id, tenant_id, spu_code, title, description, category,
  price, original_price, stock, shipping_template, status, revision

ProductMedia
  product_id, media_asset_id, sort_order, role(cover/detail/video)

MediaAsset
  id, tenant_id, object_key, sha256, mime_type, size_bytes,
  width, height, duration_ms, thumbnail_key, status, metadata_json

ContentPackage
  id, tenant_id, title, body, hashtags, media_asset_ids,
  target_platform, status, revision

PlatformAccount
  id, tenant_id, platform, display_name, status,
  device_id, authorization_expires_at, last_checked_at

PublishPlan
  id, source_type(product/content), source_id, targets_json,
  state, idempotency_key, created_by, approved_by

PublishTarget
  plan_id, account_id, device_id, platform, state,
  commit_intent_id, external_reference, evidence_asset_ids
```

设计原则：商品与内容分开；媒体是独立资产；发布计划只引用版本，不直接读取可变编辑草稿；所有发布记录保留 revision 和素材哈希，保证可追溯。

### 4.2 素材投递协议

1. Web 调用 `POST /api/v1/media/uploads` 获取预签名上传信息。
2. 浏览器上传后调用完成接口；API 校验租户、大小、MIME、SHA-256，并生成缩略图/元数据任务。
3. 发布计划创建时锁定 `media_asset_id + sha256 + revision`。
4. Worker 为每个设备生成 `artifact_delivery`，只允许下载已授权资产。
5. Companion 通过 HTTPS 下载到应用私有目录，校验长度、SHA-256、MIME 和任务签名。
6. Companion 将素材复制/导出到平台 App 可见的受控媒体目录，记录本地 URI、媒体哈希和清理时间。
7. 发布任务的 UI 步骤只引用已验证的 `mediaRef`，不允许直接接受任意路径。
8. 任务结束后保留证据和引用关系，按 TTL 清理本地副本。

### 4.3 统一发布状态机

```text
DRAFT
  -> VALIDATING
  -> AWAITING_APPROVAL
  -> QUEUED
  -> MATERIALS_DELIVERING
  -> READY_FOR_CONFIRMATION
  -> COMMITTING
  -> RECONCILING
  -> SUCCEEDED | FAILED | NEEDS_MANUAL_REVIEW | CANCELED
```

强制规则：

- `COMMITTING` 只允许一次最终提交动作。
- 设备、账号、平台三者必须匹配，账号必须为 `AUTHORIZED`。
- 失败分为可重试准备阶段和不可自动重试提交阶段。
- 最终发布按钮需要人工确认，除非后续明确启用并完成独立风险评估。
- 每一步产生结构化事件：`task_id、step_id、sequence、state、screenshot_hash、error_code`。

### 4.4 平台适配器边界

```python
class PlatformPublisher(Protocol):
    platform: str
    def validate(self, payload: PublishPayload) -> ValidationResult: ...
    def build_material_delivery(self, payload: PublishPayload) -> DeliveryPlan: ...
    def build_steps(self, payload: PublishPayload) -> list[AutomationStep]: ...
    def reconcile(self, evidence: EvidenceBundle) -> ReconcileResult: ...
```

首个适配器只做闲鱼，并且拆成四个可验收层级：打开发布页、填写字段、选择图片、人工确认后点击发布并对账。每层都有真实设备证据，未通过的层级保持 `blocked_hardware`。

## 5. 分阶段开发计划

| 阶段 | 时间盒 | 具体任务 | 交付物 | 验收标准 | 状态 |
| --- | --- | --- | --- | --- | --- |
| P0 基线修复 | 1-2 天 | 固定 Python 3.13/3.14 选择；执行 `pip install -e '.[dev]'`；锁定 protobuf/Temporal；补 CI；生成干净测试报告 | `scripts/bootstrap-dev.sh`、CI 检查、环境诊断 | 新机器按 README 可安装；`pytest` 能进入执行阶段；Web/Studio build/typecheck 通过 | 未开始 |
| P1 代码清理 | 0.5 天 | 保持测试源码；继续禁止提交 `dist/`、报告、日志、缓存；将历史交付文档标记为 reference；清理重复入口和 mock fallback 的生产路径 | 清理后的工作区、忽略规则、文档索引 | 源码与运行产物分离；生产构建无隐式 mock | 已完成基础清理 |
| P2 商品/素材模型 | 3-5 天 | 建表和迁移；商品 CRUD；素材上传、哈希去重、缩略图、标签、分组、引用；版本号和归档 | Alembic migration、API schema、Web 页面、单测 | 新建商品可关联多图/视频；编辑后 revision 增长；删除有引用时被阻止 | 未开始 |
| P3 账号与设备 | 2-3 天 | 账号平台枚举；授权状态；账号-设备绑定；设备能力矩阵；健康检查 | 账号中心、绑定流程、API/Android 状态页 | 未授权/过期/未绑定账号不能创建发布计划 | 未开始 |
| P4 素材投递 | 3-4 天 | Artifact manifest；下载签名；Companion 私有目录；SHA-256 校验；媒体可见性；清理策略 | `MediaDelivery` 协议、Android 下载器、回传事件 | 100MB 图片/视频在断网恢复后可续传或明确失败；哈希不一致必失败 | 未开始 |
| P5 闲鱼字段发布 | 3-5 天 | 商品字段映射；图片选择步骤；价格/描述输入；前置校验；人工确认页 | 闲鱼 V1 adapter、任务 schema、UI 预览 | 真实设备可打开发布页并填充商品和图片；不点击发布也能完整留证 | 部分已有 |
| P6 闲鱼最终发布 | 2-4 天 | `commit_intent`；人工确认；单次点击；发布结果识别；对账和失败人工复核 | 发布中心、证据链、状态机 | 成功/失败/未知三态正确；未知不自动重发；重复幂等 | 未开始 |
| P7 内容平台基础 | 5-8 天 | 小红书、抖音、公众号统一 ContentPackage；每个平台格式校验；素材适配器；先支持草稿/预填 | 内容库、平台能力矩阵、适配器契约 | 不满足平台格式时发布前阻断；至少一个平台真实预填验收 | 未开始 |
| P8 一键发布编排 | 3-5 天 | 多目标计划；按平台拆 target；队列、并发限制、暂停、取消、审计 | 发布计划页、批次执行、审计导出 | 一次操作可生成多个 target；一个失败不影响其他 target；状态可追踪 | 未开始 |
| P9 真实设备验收 | 5-10 天 | OnePlus 9R 授权、无 ADB 运行、通知/电池优化、断网/重启/锁屏测试 | 硬件证据包、兼容矩阵、问题清单 | 任务在 ADB 断开后仍可执行；关键证据来自真实设备而非 mock | 未开始 |
| P10 V1 发布 | 2-3 天 | release signing；生产 OIDC；对象存储；备份；灰度；回滚演练 | release APK、部署 runbook、SLO/告警 | 可审计、可回滚、可停止；发布失败可定位 | 未开始 |

## 6. 具体实施流程

### 每个功能的固定执行顺序

1. 先写数据契约和状态转换表。
2. 再写 API schema 与迁移。
3. 再写服务层和审计事件。
4. 再写 Web 表单/列表/状态展示。
5. 再写 Android/Edge 任务协议。
6. 先用 mock 证明逻辑，再用真实设备证明 UI 和媒体路径。
7. 为成功、参数错误、未授权、过期、重复请求、断网、进程重启、未知结果分别写测试。
8. 只有证据文件、日志和状态回放齐全，任务才从 `implemented` 进入 `accepted`。

### “一键发送商品”操作流

1. 用户选择商品版本。
2. 系统展示商品字段、媒体哈希、目标平台和账号。
3. 预校验：账号授权、设备在线、媒体格式、尺寸、数量、描述长度、价格。
4. 创建 `PublishPlan` 和一个或多个 `PublishTarget`，生成幂等键。
5. 目标设备领取租约，下载并校验素材。
6. 手机打开闲鱼并填充字段、选择图片。
7. Web 显示“待人工确认”，用户查看手机预览/截图后确认。
8. Companion 执行一次发布提交。
9. API 进入 `RECONCILING`，根据页面结果、截图、任务事件和平台可见状态判断成功/失败/未知。
10. 成功归档商品版本、账号、设备、素材哈希、证据；未知状态进入人工复核，禁止自动重发。

### “一键发送素材”操作流

1. 用户选择 `ContentPackage` 和目标平台。
2. 系统按平台能力矩阵校验图文/视频格式、数量、比例、时长、标题和正文。
3. 创建内容发布目标并锁定素材版本。
4. 设备端下载并校验素材，写入受控媒体目录。
5. 打开目标 App，执行预填/草稿步骤。
6. 对需要发布的动作统一显示人工确认。
7. 回传截图、页面状态、错误码和素材引用。
8. 生成可重放的执行摘要，但不自动重复最终提交。

## 7. 立即执行清单

按以下顺序开始，不要先扩展 134 个目录功能：

1. 修复 Python 依赖与 CI，使全量测试至少能完成收集。
2. 删除或隔离所有运行产物；保留测试源码和安全测试。
3. 建立 V1 数据迁移：`products`、`product_media`、`content_packages`、`media_delivery`、`publish_targets`。
4. 把现有通用 `ContentItem` 映射到明确的商品/内容 API，避免继续把商品当帖子处理。
5. 完成素材投递协议，再做闲鱼图片选择；没有素材投递协议时不要继续堆 UI。
6. 把闲鱼发布从“文本预填”推进到“图片选择 + 人工确认 + 单次提交 + 对账”。
7. 用当前已连接的 OnePlus 9R 做真实验收，但执行最终发布前必须建立测试账号、测试商品和可撤销的人工确认流程。
8. 第一版只验收闲鱼；小红书、抖音、微信公众号先完成契约和格式校验，按平台逐个接入。

## 8. 风险与决策门

| 风险 | 影响 | 决策门 |
| --- | --- | --- |
| 平台 UI 改版 | 定位器失效、发布失败 | 每个平台维护版本化 locator 集合和真实设备回归 |
| 登录态/授权失效 | 任务无法执行或误发账号 | 发布前强校验授权状态，失败不得自动重试 |
| 媒体进入系统相册的权限和可见性 | 图片选择器找不到素材 | 每种 Android 版本做可见性验收，失败时使用受控 fallback |
| 发布结果不确定 | 重复发帖/重复商品 | commit_once + reconcile，未知状态人工复核 |
| 账号风控或平台规则 | 账号受限 | 仅控制自有/明确授权账号，限制频率，保留人工确认和审计 |
| 调试 APK 上生产 | 安全与升级风险 | release 签名、版本校验、回滚演练完成前禁止生产 |
| 过度扩展范围 | 交付延期、质量下降 | V1 只做闲鱼闭环和内容平台预填能力 |

## 9. 证据等级

- **已验证：**Web 39 个前端单测、Studio 16 个前端单测通过；APK 已安装到设备；代码中存在账号/素材/内容/移动任务路由。
- **未验证：**Python 全量测试通过。当前失败发生在收集阶段，主要原因是环境依赖不完整。
- **不可由 mock 推导：**真实 LAMDA 操作、无 ADB 运行、素材在目标 App 选择器中可见、平台最终发布成功、账号授权长期有效。

历史文档 `docs/delivery/task-status.md`、`docs/delivery/functional-delivery-progress-2026-09-01.md` 等仅作为历史交付材料保留；本文件是 2026-09-05 起的新计划基线。
