import { FileBlob, SpreadsheetFile } from '@oai/artifact-tool';
const path='/Users/wangziheng/Desktop/LAMDA云控系统_代码交接包_20260901/LAMDA云控系统_V1开发进度表_20260905.xlsx';
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(path));
const s=wb.worksheets.getItem('开发任务');
s.getRange('C7:F7').values=[['100%','已完成','工程基线、依赖、构建、前端单测、Python 全量测试均通过','pytest 383 passed；历史归档校验规则已与清理策略一致']];
s.getRange('A17:F24').values=[
 ['P0-01','补齐项目虚拟环境 pip 与开发依赖','100%','已完成','可导入 fastapi、protobuf、temporalio、pytest','安装成功'],
 ['P0-02','修复 Web TypeScript 构建错误','100%','已完成','Web build 通过','OperationsView.vue 类型修复'],
 ['P0-03','验证 Studio 构建','100%','已完成','Studio build 通过','vite build 成功'],
 ['P0-04','验证 Web/Studio 单测','100%','已完成','Web 39/39；Studio 16/16','Vitest 通过'],
 ['P0-05','运行 Python 全量测试','100%','已完成','全量测试通过','383 passed in 11.77s'],
 ['P0-06','修复测试环境代理干扰','100%','已完成','代理环境下测试稳定','trust_env=False 定向测试通过'],
 ['P0-07','处理历史硬件证据校验','100%','已完成','checksums 与文件一致','重建受影响任务清单并更新测试策略'],
 ['P0-08','更新进度表','100%','已完成','记录命令、结果、阻塞','已更新至 2026-09-05'],
 ['P2-01','新增 Product/ProductMedia 数据模型与迁移','100%','已完成','迁移可升级/回退；商品与素材通过外键关联','20260905_0009；迁移测试通过'],
 ['P2-02','商品 API 契约与字段校验','100%','已完成','SPU、标题、描述、分类、价格、库存、媒体集合可校验','OpenAPI 已重新生成；专用接口测试通过'],
 ['P2-03','商品 CRUD 与审计','45%','进行中','租户隔离、版本递增、归档和引用保护','创建/列表/创建审计已实现；编辑/归档待实现'],
 ['P2-04','商品 Web 列表/编辑','0%','未开始','可新建、编辑、关联素材、查看 revision','未开始'],
 ['P2-05','素材标签/分组与引用视图','0%','未开始','素材可检索且能显示被哪些商品/内容引用','未开始'],
 ['P2-06','商品 API 初版与媒体归属校验','100%','已完成','POST/GET products；SPU 唯一；媒体必须同租户','专用接口测试通过；OpenAPI 合同通过'],
];
const t=wb.worksheets.getItem('测试验收');
t.getRange('A7:D13').values=[
 ['2026-09-05','Web build','通过','vue-tsc + vite build'],
 ['2026-09-05','Studio build','通过','vue-tsc + vite build'],
 ['2026-09-05','Web/Studio Vitest','通过','Web 39/39；Studio 16/16'],
 ['2026-09-05','Python 依赖安装','通过','项目 .venv 开发依赖安装成功'],
 ['2026-09-05','Python pytest','通过','383 passed in 11.77s'],
 ['2026-09-05','httpx 代理测试','通过','trust_env=False 后通过'],
 ['2026-09-05','源归档完整性','通过','硬件任务校验清单与清理策略一致'],
 ['2026-09-05','商品模型/API 定向测试','通过','迁移、商品接口、权限和 OpenAPI 测试通过'],
];
const i=wb.worksheets.getItem('问题清单');
i.getRange('D3:E3').values=[['已完成','修复 OperationsView.vue 参数对象类型']];
i.getRange('D2:E2').values=[['已完成','项目 .venv 已补齐开发依赖；pytest 已完整执行']];
i.getRange('D4:E4').values=[['已完成','历史硬件任务 checksums 已按保留证据重建']];
i.getRange('A5:E5').values=[['P2-CRUD-01','商品编辑、归档和媒体排序接口尚未实现','P1','进行中','补详情/更新/归档/媒体排序与 revision 测试']];
const summary=wb.worksheets.getItem('总览');
summary.getRange('B9:C9').values=[['P0 基线修复（100%）','Web/Studio 构建、前端单测、Python 383 测试全部通过']];
const out=await SpreadsheetFile.exportXlsx(wb); await out.save(path); console.log(path);
