import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';
const out = '/Users/wangziheng/Desktop/LAMDA云控系统_代码交接包_20260901/LAMDA云控系统_V1开发进度表_20260905.xlsx';
const wb = Workbook.create();
const summary = wb.worksheets.add('总览');
const tasks = wb.worksheets.add('开发任务');
const tests = wb.worksheets.add('测试验收');
const issues = wb.worksheets.add('问题清单');
const rows = [
  ['LAMDA 云控系统 V1 开发进度表','基线日期','2026-09-05'],
  ['总体估算进度','40%','架构骨架较完整，业务闭环未完成'],
  ['当前主线','P0 基线修复','Python 依赖、Web 构建、可重复验证'],
  ['下一业务目标','闲鱼单商品单账号发布闭环','素材投递、图片选择、人工确认、单次提交、结果对账'],
  [],
  ['阶段','目标','完成度','状态','验收标准','当前说明'],
  ['P0','修复工程与测试基线','0%','进行中','Python 全量测试可收集；Web/Studio build 通过','已发现缺少 google.protobuf、temporalio；Web 有 TS 错误'],
  ['P1','清理运行产物','100%','已完成','源码目录无日志、缓存、测试报告、构建产物','已清理'],
  ['P2','商品库与素材库','0%','未开始','商品版本可关联多媒体；素材哈希去重和引用可追踪','已有通用内容/媒体 API 骨架'],
  ['P3','账号与设备绑定','0%','未开始','未授权账号不可创建发布计划','已有账号、绑定、租约 API'],
  ['P4','素材投递到 Android','0%','未开始','下载、哈希校验、受控媒体目录、清理策略','当前未完成'],
  ['P5','闲鱼字段与图片发布','25%','部分完成','真实设备可填字段、选图并留证','当前仅文本和价格预填'],
  ['P6','人工确认与最终发布','0%','未开始','commit_once、对账、未知状态不重发','当前未完成'],
  ['P7','小红书/抖音/公众号基础适配','0%','未开始','格式校验和素材预填','V1 后续阶段'],
  ['P8','多目标一键编排','0%','未开始','多个目标独立追踪，单个失败不影响其他目标','V1 后续阶段'],
  ['P9','真实设备验收','0%','未开始','断开 ADB 后仍可执行，真实证据完整','设备已连接，但尚未完成闭环'],
];
tasks.getRangeByIndexes(0,0,rows.length,6).values=rows;
const testRows=[
 ['时间','范围','结果','证据/问题'],
 ['2026-09-05','Web Vitest','通过：39 个测试','前端单测通过'],
 ['2026-09-05','Studio Vitest','通过：16 个测试','Studio 单测通过'],
 ['2026-09-05','Python pytest','失败：收集阶段','缺 google.protobuf、temporalio；未删除测试源码'],
 ['2026-09-05','Web build','失败：TypeScript','OperationsView.vue:534-535 JsonObject 类型错误'],
 ['2026-09-05','ADB','设备在线','OnePlus 9R，b0644fb5；Companion 0.1.0 已安装'],
];
tests.getRangeByIndexes(0,0,testRows.length,4).values=testRows;
issues.getRangeByIndexes(0,0,5,5).values=[
 ['编号','问题','优先级','状态','处理动作'],
 ['P0-001','Python 虚拟环境缺少 protobuf、Temporal 依赖','P0','进行中','补齐依赖并重新运行 pytest'],
 ['P0-002','Web 构建存在 JsonObject 类型错误','P0','未开始','修复 OperationsView.vue 参数对象类型'],
 ['P0-003','项目源码根目录无 Git 元数据','P1','待决策','建立版本控制或接入现有仓库'],
 ['P1-001','闲鱼尚未实现图片选择和最终提交','P1','未开始','先完成素材投递协议，再做真实设备验收'],
];
summary.getRangeByIndexes(0,0,9,3).values=[
 ['LAMDA 云控系统 V1 进度总览','值','说明'],
 ['基线日期','2026-09-05','重新开始审视'],
 ['总体估算进度','40%','项目管理估算，不是测试测量值'],
 ['Web 单测','39/39 通过','Vitest'],
 ['Studio 单测','16/16 通过','Vitest'],
 ['Python 全量测试','未通过收集','环境依赖不完整'],
 ['Web 构建','未通过','OperationsView.vue 类型错误'],
 ['ADB','在线','OnePlus 9R / b0644fb5'],
 ['当前阶段','P0 基线修复','完成后进入商品/素材模型'],
];
for (const s of [summary,tasks,tests,issues]) { const used=s.getUsedRange(); used.format.autofitColumns(); used.format.autofitRows(); }
summary.getRange('A1:C1').format = { fill:'#1F4E78', font:{bold:true,color:'#FFFFFF'} };
tasks.getRange('A6:F6').format = { fill:'#1F4E78', font:{bold:true,color:'#FFFFFF'} };
tests.getRange('A1:D1').format = { fill:'#1F4E78', font:{bold:true,color:'#FFFFFF'} };
issues.getRange('A1:E1').format = { fill:'#1F4E78', font:{bold:true,color:'#FFFFFF'} };
const file=await SpreadsheetFile.exportXlsx(wb); await file.save(out);
console.log(out);
